# wifinder
Tool for geographically mapping wireless networks

# Contributing:
It's advisable to setup a virtual environment for working on this project to prevent messing up other Python projects you have stored on your workstation.
Guide for installing and using VirtualEnv: http://docs.python-guide.org/en/latest/dev/virtualenvs/

If you want to work on an issue, firstly create a new branch and work on that. Never work on the master branch!
