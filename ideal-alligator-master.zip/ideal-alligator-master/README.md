# ideal-alligator
PowerShell script to retreive wifi ESSIDs and Passwords.

Current version delievers via Microsoft Macro written in Visual Basic for Applications.
