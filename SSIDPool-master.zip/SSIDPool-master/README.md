# SSIDPool
PineApple WiFI SSID manager module

This is a PineApple WiFi module allowing you to:

- backup current SSID pool file
- Download/View/Delete backuped SSID file
- Restore a previously backuped SSID file
- Merge all SSID files to a single one and restore it
