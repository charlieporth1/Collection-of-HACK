package main

import "github.com/hnw/mackerel-plugin-iw/lib"

func main() {
	mpiw.Do()
}
