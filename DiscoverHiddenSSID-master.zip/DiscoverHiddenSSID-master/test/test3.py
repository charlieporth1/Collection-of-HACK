#!/usr/bin/python
#-*-coding: utf-8 -*-
import sys, os
import binascii
from scapy.all import *

with open('text.txt', a) as t:
	t.write('hahah')


