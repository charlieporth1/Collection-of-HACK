# Simple iwscan

Simple wifi scanner using iwlib

Select an AP and monitor power strenght

## Compilation 

``` gcc-o wifi wifi.c -liw```
