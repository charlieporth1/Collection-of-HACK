/*
  base64.h

  Base-64 routines.

  $Id: base64.h,v 1.1.1.1 2004-07-30 11:36:18 cmn Exp $
*/

#ifndef BASE64_H
#define BASE64_H

int	base64_pton(char const *, u_char *, size_t);

#endif /* BASE64_H */

