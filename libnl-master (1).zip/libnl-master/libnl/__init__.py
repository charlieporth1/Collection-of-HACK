"""Metadata about the library for setup.py."""

__author__ = '@Robpol86'
__license__ = 'LGPL2.1'
__version__ = '0.2.0'
__upstream__ = '3.2.25'
