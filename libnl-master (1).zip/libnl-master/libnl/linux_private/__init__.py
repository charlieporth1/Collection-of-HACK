"""Code not usually available to C libnl user applications but used by libnl itself."""
