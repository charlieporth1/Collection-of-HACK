First of all Piapple is a wireless penetration testing tool


Requaments 

Minamam:
	System
		CPU: 700 MHz ARM1176JZF-S core
		GPU: What ever works 
		256 MB RAM
		Singel USB 2.0 port

	Network Adapters
		
		Atheros Ath9
		10/100 Mbps Eathernet (To provide clients with internet accsess)

	Software 

		Debian based operating system
		Python 2.7.8 or higher

Recommend:
	System 
		CPU: 1 GHz ARM1176JZF-S core
		GPU: What ever works
		512 MB RAM
		Dule USB 2.0 ports

		Network Adapters

		Dule RTL8187
		10/100 Mbps Eathernet (optinal)

	Software 

		Debian based operating system
		Python 3.1.4 or higher