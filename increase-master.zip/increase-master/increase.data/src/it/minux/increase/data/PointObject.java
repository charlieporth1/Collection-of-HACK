package it.minux.increase.data;

import gov.nasa.worldwind.geom.LatLon;

public abstract class PointObject {

	private final LatLon location;
	
	public PointObject(LatLon location) {
		this.location = location;
	}
	
	public LatLon getLocation() {
		return this.location;
	}	
}
