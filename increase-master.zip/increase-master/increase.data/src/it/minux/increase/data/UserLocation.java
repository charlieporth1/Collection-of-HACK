package it.minux.increase.data;

import it.minux.increase.xml.UserLocationType;

public class UserLocation 
	extends PointEvent
{
	public UserLocation(UserLocationType event) {
		super(event);
	}
}
