package it.minux.increase.utils;

public interface IFilter<T> {
	
	boolean accept(T o);

}
