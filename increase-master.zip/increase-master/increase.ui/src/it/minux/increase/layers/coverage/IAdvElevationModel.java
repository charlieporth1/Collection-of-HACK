package it.minux.increase.layers.coverage;

import gov.nasa.worldwind.geom.Sector;
import gov.nasa.worldwind.globes.ElevationModel;

public interface IAdvElevationModel 
	extends ElevationModel
{

	void loadMaxResolution(Sector sector, int level);
}
