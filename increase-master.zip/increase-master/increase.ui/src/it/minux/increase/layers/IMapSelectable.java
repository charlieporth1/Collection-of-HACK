package it.minux.increase.layers;

public interface IMapSelectable {

	void onHover();
	void onClick();
}
