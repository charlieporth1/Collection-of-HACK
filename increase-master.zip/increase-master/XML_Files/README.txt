This folder contains sample XML files that are fed in input to 
the IncrEase tool.

Each file only contains a couple of items with the purpose of 
showing the correct syntax.
