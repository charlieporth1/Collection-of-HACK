# Vulnerabilities exploited:

**At the moment this tools exploit only Netgear Routers**

This tools take advantage **only** of vulnerabilities that expose the admin password, it does not try to upload file or DOS the target

At the moment routerPWN can check the fallowing vulnerabilities on Netgear Routers:

---

CVE-2017-5521 (https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2017-5521)

CVE-2016-5649 (https://packetstormsecurity.com/files/cve/CVE-2016-5649)

BID72640 (http://www.securityfocus.com/bid/72640)

---
