# Releases

---
## ver 0.5 alpha
First public release
### Done
* Identify Router brand/model (only Netgear, Linksys and D-link)
* Check for vulnerability and exploit (only Netgear)
* Check for default password (only Netgear)

### To Do
* Improve output, including an option for the "verbose" mode
* Improve router fingerprinting
* Add more brand identification
* ...
___

