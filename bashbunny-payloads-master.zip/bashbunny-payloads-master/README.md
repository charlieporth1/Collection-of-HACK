# Payload Library for the Bash Bunny by Hak5

![Bash Bunny](https://www.hak5.org/wp-content/uploads/2017/10/icon3-169x169.png)

* [Purchase at HakShop.com](https://hakshop.com/products/bash-bunny "Purchase at HakShop.com")
* [Documentation and Wiki](http://wiki.bashbunny.com/#!index.md "Documentation and Wiki")
* [Bash Bunny Forums](https://forums.hak5.org/index.php?/forum/92-bash-bunny/ "Bash Bunny Forums")
* IRC: irc.hak5.org #BashBunny
