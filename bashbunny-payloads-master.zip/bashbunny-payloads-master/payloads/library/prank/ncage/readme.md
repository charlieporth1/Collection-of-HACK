
# nCage

Author: audibleblink
Version: 2.0

## Description

ATTENTION: Requires newest firmware (1.5+) with newest extensions

Installs the ncage (or any) Google Chrome extension
using jquery which is kindly supplied by the app store.

## Configuration
* Configure each ducky.{win,osx} file to your liking

## Requirements
Just plug and play

## Status
| LED              | Status              |
| ---------        | -----------         |
| Magenta Solid    |  Setting up         |
| Blue Blinking    |  Attacking          |
| Green            |  Finished           |

