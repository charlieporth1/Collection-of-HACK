# Startup-Message
by KMikeeU

* Target: Windows
* Tested on: Windows 10
* Should work on: Windows XP, Vista, 7, 8(Desktop), 10
* Version: 1.0

## Description
This little __HID__ Attack, will use cmd to create a file in the startup directory of the logged in user on the target PC. Which will display a message set by the attacker on logging in.

## Configuration
You can edit the script to change the name of the file and the text that will be displayed.
Defaults: startup.bat; I will lock my PC next time!

## Status
| Status | Color | Description |
|------|------|------|
|SETUP|Magenta|Setting Attack mode|
|ATTACK|Slow Yellow|Injecting keystrokes|
|FINISH|Fast Green followed by solid|Payload has finished!|

