## Lock PC Prank

* Author: Frater V:I:
* Version: Version 1.0
* Target: Linux, Windows, OSX

## Description
A variation of the Notepad fun payload written by The10FpsGuy and Mrhut10

## Configuration

None

## Status
LED SETUP - detecting OS using get.sh extension

LED ATTACK - launching the payload based on OS detected

LED FAIL3 - No OS detected

LED FINISH - system should be locked and payload is done

## Discussion
