# Photo booth ugly prank for Bash Bunny

* Author: Jafahulo
* Version: Version 1.0
* Target: OSX

## Description

Quick payload that takes a photo of target, and tells them that they're ugly

REQUIRES THE BASH BUNNY TO BE PLUGGED IN THE FULL TIME

## Configuration

None needed

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Red (blinking)     | Running                                      |
| Green              | Attack Complete                              |

## Discussion
none
