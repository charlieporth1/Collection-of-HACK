# UnifiedRickRoll for Bash Bunny

* Author: Jafahulo
* Version: Version 1.0
* Target: OSX

## Description
Runs a script in background that will crank up volume and rick roll target at specified time.

## Configuration

set time to run in payload.txt

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Red (blinking)     | Running                                      |
| Green              | Attack Complete                              |

## Discussion
https://forums.hak5.org/index.php?/topic/40618-payload-unifiedrickroll/
