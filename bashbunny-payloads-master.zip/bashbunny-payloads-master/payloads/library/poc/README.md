# Proof of concepts and malware simulators

The payloads contained in here are to test protection technology.

"The Eicar of BashBunny attacks"

Criteria:
- one trick pony, as simple as possible
- the essence of one attack
- no side effects
- simple to test with (ui and file system markers left by attack)
- non-destructive/invasive
