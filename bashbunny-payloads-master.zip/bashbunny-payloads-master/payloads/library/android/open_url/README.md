# android_open_url for Bash Bunnys

* Author: bg-wa
* Version: Version 1.0
* Target: Android 4.2.2

## Description

Opens the browser to a specified url on an unlocked android phone.

## Configuration

**By default this script will open https://www.hak5.org**  

Set the URL param as desired.

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Green              | Working                                      |
| Red                | Finished                                     |
