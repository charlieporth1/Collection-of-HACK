#Set variables for use in payload.
$proxyVal = "proxyip:port"
$certName = "cert.pem"
