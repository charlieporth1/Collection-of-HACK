# Infinite Control For Bash Bunny

Author: Didier Stevens

Version: Version 0.0.1

## Description

Hit the CONTROL key every 10 seconds in an infinite loop, while blinking the red LED with every keypress.

## STATUS

| LED              | Status                                |
| ---------------- | ------------------------------------- |
| Red flash        | CONTROL keypress                      |


