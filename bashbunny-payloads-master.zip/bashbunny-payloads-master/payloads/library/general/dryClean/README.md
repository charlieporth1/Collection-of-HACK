# dryClean

* Author: ricky5ive
* Version: Version 1.0
* Target: N/A
* Category: CYA
* Attackmodes: N/A

## Description

Removes loot directory along with contents. Will remove ANY loot directory located on the BashBunny

## STATUS

| LED                 | Status                                 |
| ------------------- | -------------------------------------- |
| White (fast blink)  | Running                                |
| Red (fast blink)    | Failed to remove loot directory        |
| Green               | Finished                               |
|                     |                                        |
