# Ducky Script Template for Bash Bunnys

Author: @kevthehermit
Version: Version 1.1

## Description

Boiler Plate for running ducky scripts on the Bash Bunny

## Configuration

HID or HID STORAGE

## Requirements

Install DuckToolkit payload for extra language support

## STATUS

| LED                                              | Status                      |
| ------------------------------------------------ | --------------------------- |
| Magenta solid                                    | Setup                       |
| Yellow single blink                              | Script Running (Attack)     |
| Green 1000ms VERYFAST blink followed by SOLID    | Finished                    |
