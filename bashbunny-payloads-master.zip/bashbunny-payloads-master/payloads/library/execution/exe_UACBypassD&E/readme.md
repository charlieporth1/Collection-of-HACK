# UACBypass / UACExploit -  Download and executes any binary executable with administrator privileges WITHOUT UAC prompting for access

Author: @SkiddieTech 
Version: Version 1.1
Target:  Windows 7 - Windows 10 (V1607)

## Description

Download and executes any binary executable with administrator privileges WITHOUT
prompting the user for administrator rights (aka UAC bypass/exploit)
Please define URL and SAVEFILENAME in the a.vbs script 
Target does need internet connection
Works on Windows 7 - Windows 10
The UAC bypass was patched in Win10 V.1607, the file will still execute but with normal user privliges 
However from what i am aware version 7,8 and 8.1 are still effected 
Currently fastest download and execute for HID attacks to date. (with UAC bypass)
## Configuration

HID or HID STORAGE

## Requirements

Target must be an Windows box with an working internet connection,powershell and vb script enabled (enabled by default) 
Please edit the a.vbs script with your binary payload URL and savename 

## STATUS

| LED              | Status                                |
| ---------------- | ------------------------------------- |
| Red              | Script is starting                    |
| Green            | Finished                              |

