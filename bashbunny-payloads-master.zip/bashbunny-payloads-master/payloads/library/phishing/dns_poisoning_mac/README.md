# DNS Poisoning Attack Mac

## Description

Redirects a domain to a set IP adres by changing the hosts file.

## Configuration

Change the domain you want to redirect and the IP you want to direct it to.
