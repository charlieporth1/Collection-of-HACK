# GetServicePerm

* Title:         GetServicePerm
* Author:        Resheph @ www.postexplo.com
* Version:       0.1
* Target:        Microsoft Windows hosts supporting PowerShell
* Category:      Recon

## Description

When executed on a Windows host the payload gathers a list of permissions on executables used as a service.
This is useful when a service is executed with elevated privileges but is modifiable by everyone.
When this senario exists a normal user can modify or replace that executable with anything useful and have it run with elevated privileges.

## Configuration

The only thing you will need to change is the Ducky language so it matches the target.

## STATUS

LED SETUP
LED FINISH

## Discussion

