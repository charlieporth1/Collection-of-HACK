# Linux Info Grabber

Author: Thorsten Sick

Version: 0.9

OS: Linux (Debian based)

Attackmode: HID STORAGE

Description: System info grabber for Linux (focus: Debian)

Category: Recon

Creds: Simen Kjeserud for Inspiration (Info_Grabber)

executes recon.sh to extract sytem info


## Description

Extract system information. Uses debian apt to list installed applications.

System info will be stored in loot dir


## Status

|LED|Status|
|-|-|
|SETUP (Magenta solid)|Not much setup needed|
|ATTACK (Yellow single blink)|attack|
|FINISH (Green 1000ms VERYFAST blink followed by SOLID)|Done|
