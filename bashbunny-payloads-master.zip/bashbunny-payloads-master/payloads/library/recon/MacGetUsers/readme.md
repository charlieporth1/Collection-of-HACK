# Mac User Lister for the BashBunny

* Author: ericfri
* Version: Version 1.0
* Target: OSX

## Description

A payload that lists the users on the system and creates a file inside a folder on the BashBunny called MacLoot/MacUsers.


## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Amber              | Executing Payload                             |
| Green              | Attack Finished                              |
