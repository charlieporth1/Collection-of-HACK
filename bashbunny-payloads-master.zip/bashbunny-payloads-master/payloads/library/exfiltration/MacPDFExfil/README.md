# MacPDFExfil

Author: k1ul3ss  
Version: Version 1.0  
Target: macOS  

## Description

Mounts as storage and acts as HID. Backup PDF files to the BashBunny

## Configuration

Configured to copy all PDFs located in the users home directory to the BashBunnny

## STATUS