# Powershell TCP extractor for Bash Bunnys

* Author: $irLurk$alot
* Version: Version 1.0
* Target: Windows

## Description

Copies data to temp directory and uses powershell tcp socket to extract to a listener on remote machine

## Configuration
The payload copies target to %APPDATA%, change this to wherever you like by editing powershell script, 
it then zips data and sends data to listener on a remote machine, also specified in powershell script.

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Red                | Attack Setup                                 |
| Purple             | Attack Execution                             |
| White              | Attack Complete (safe to remove Bunny)       |
|					 | Script will continue to run and transmit		|	
## Discussion
[Hak5 Forum Thread](https://forums.hak5.org/index.php?/forum/92-bash-bunny/ "Hak5 Forum Thread")
