# NothingLess for Bash Bunnys

* Author: StinkyBliss
* Version: Version 1.0
* Target: Windows

## Description

For testing use: 'icacls "c:\Users" /remove:g Everyone /T' to remove the created security permissions
To share a drive change the path in nl.cmd to c: remove the quotes

## Configuration

None, only optionl changes 

## STATUS

| LED                | Status                                       |
| ------------------ | -------------------------------------------- |
| Red (blinking)     | Setting up                                   |
| yellow (blinking)  | Attack running                               |
| Green              | Attack Complete                              |
| ------------------ | -------------------------------------------- |
