# osx_wireless_monitor

A python and bash tool for simplifying wireless monitoring on OSX.

