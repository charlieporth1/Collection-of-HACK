# Hush

A sexy, no-nonsense native password hasher for Mac OS X.

<img alt="Screen shot of Hush" src=ScreenShots/Hush.png width=400 height=180>

With lots of options.

<img alt="Screen shot of Hush's options" src=ScreenShots/Options.png width=400 height=381>

And then some more options.

<img alt="Screen shot of Hush's preferences" src=ScreenShots/Preferences.png width=570 height=403>

It also runs on iOS.

<img alt="Screen shot of Hush on iOS" src=ScreenShots/iOSHush.png width=375 height=667>

And still has lots of options.

<img alt="Screen shot of Hush's options on iOS" src=ScreenShots/iOSOptions.png width=375 height=667>

And some other options.

<img alt="Screen shot of Hush's preferences on iOS" src=ScreenShots/iOSPreferences.png width=375 height=667>
