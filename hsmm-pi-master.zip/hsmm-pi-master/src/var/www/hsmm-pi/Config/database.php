<?php
class DATABASE_CONFIG {

	public $default = array(
		'datasource' => 'Database/Sqlite',
		'persistent' => false,
		'database' => '/var/data/hsmm-pi/hsmm-pi.sqlite',
	);
}
