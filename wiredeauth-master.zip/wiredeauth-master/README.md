
# WireDeauth - deauthentication tool for wireless attacks


## Compilation

(Some modes depend on the nl80211 library to set the wireless channel of the device in use)

Create a .config file in the src/ folder (see defconfig for a default configuration)

With the netlink libraries available if required, run make

Run with '-h' or '--help' to display the usage options.


## Doc

Run 'make documentation' to generate the documentation.


