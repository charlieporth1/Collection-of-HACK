var config = {
                "serverIp": "127.0.0.1",
                "serverPort": "8888",
                "defaultLat": "40.7128",
                "defaultLong": "74.0059",
                "defaultZoom": 8,
                "wigleAuthToken": "<WIGLE_API_TOKEN_IN_BASE64>",
                "googleMapsAPIKey": "<GOOGLE_MAPS_API_KEY>",
                "whitelist": [],
                "blacklist": []
              }
