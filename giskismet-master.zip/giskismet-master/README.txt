GISKismet - Version .02 ( http://www.giskismet.org )

GISKismet is a wireless recon visualization tool to represent data gathered
using Kismet in a flexible manner. GISKismet stores the information in a
database so that the user can generate graphs using SQL. GISKismet currently
uses SQLite for the database and GoogleEarth / KML files for graphing.

GISKismet supports Kismet-newcore and Kismet-devel.

Let me know what you think.

Joshua D. Abraham (jabra@spl0it.org)
