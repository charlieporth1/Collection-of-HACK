#include<stdio.h>
#include<string.h>
#include<sys/socket.h>
#include<stdlib.h>
#include<errno.h>
#include<netinet/ip.h>
#include<linux/if_packet.h>
#include<linux/if_ether.h>
#include<linux/if_arp.h>

//github.com/DragonFlyBSD/DragonFlyBSD/blob/master/sbin/dhclient/packet.c
//https://austinmarton.wordpress.com/2011/09/14/sending-raw-ethernet-packets-from-a-specific-interface-in-c-on-linux/

void copy(char *current,char *in,int size){
	//simple way to deal with \x00's better than spending time writing algorithm
	int i;
	for(i = 0;i < size;i++){
		strncpy(current,in,1);
		current += 1;
		in +=1;
	}
}

/*
 * This will convert www.google.com to 3www6google3com 
 * http://www.binarytides.com/dns-query-code-in-c-with-linux-sockets/
 * */
void ChangetoDnsNameFormat(unsigned char* dns,unsigned char* host) {
	int lock = 0 , i;
	strcat((char*)host,".");

	for(i = 0 ; i < strlen((char*)host) ; i++) 
	{
		if(host[i]=='.') 
		{
			*dns++ = i-lock;
			for(;lock<i;lock++) 
			{
				*dns++=host[lock];
			}
			lock++; //or lock=i+1;
		}
	}
	*dns++='\0';
}

char *cpw(char *s,int size){
	char *returning = calloc(size,sizeof(char));
	copy(returning,s,size);
	return returning;
}

void usage(){
	printf("\nsudo ./hex-dns.reply <src ip> <src port> <dst ip> <dst port> <query name> <answer ip> <query id>\n");
}

void main(int argc, char **argv){
	if(argc < 8){
		usage();
		return;
	}

	//Create a raw socket
	int s = socket(AF_PACKET, SOCK_RAW, IPPROTO_RAW);

	//socket doesnt matter, changed port and ip in udp & ip header
	struct sockaddr_in sin;
	sin.sin_family = AF_INET;
	sin.sin_port = htons(80);
	sin.sin_addr.s_addr = inet_addr ("1.2.3.4");

	//construct packet
	char *datagram = calloc(4096,sizeof(char));

        char *iphdr = cpw("\x45\x00\x00\x4f\x00\x00\x40\x00\x40\x11\xfb\x8b\x0a\x0a\x00\x01\x0a\x0a\x00\x01",16);
	unsigned short *iplen = (unsigned short*) (iphdr + 2);
	in_addr_t *ipsrc = (in_addr_t*) (iphdr + 12);
	in_addr_t *ipdst = (in_addr_t*) (iphdr + 16);

	char *udphdr = cpw("\x00\x35\x00\x35\x00\x00\x7e\x93",8);
	unsigned short *portsrc = (unsigned short*) (udphdr);
	unsigned short *portdst = (unsigned short*) (udphdr + 2);
	unsigned short *udplen = (unsigned short*) (udphdr + 4);

	char *dnshdr = cpw("\x95\xa9\x81\x80\x00\x01\x00\x01\x00\x00\x00\x00",12);
	unsigned short *dnsid = (unsigned short*) (dnshdr);

	//as dns format of query name starts with a letter
	int querySize = 1+strlen(argv[5])+1+4;
	char *query = calloc(querySize,sizeof(char));
	char *dnsFormatName = calloc(strlen(argv[5])+2,sizeof(char));
	char *dnsName = calloc(strlen(argv[5])+2,sizeof(char));
	strcpy(dnsName,argv[5]);
	//as changetoDNSNameFormat seems to mess up argv[5] and theirfore argv[6/7]
	ChangetoDnsNameFormat(dnsFormatName,dnsName);
	copy(query,dnsFormatName,(strlen(dnsFormatName)+1));
	char *endqueryPos = (char *) (query + strlen(dnsFormatName)+1);
	char *endquery = "\x00\x01\x00\x01";
	copy(endqueryPos,endquery,4);

	char *answer = cpw("\xc0\x0c\x00\x01\x00\x01\x00\x00\x0e\x10\x00\x04\xAC\x10\xC8\x01",16);
	in_addr_t *ansaddr = (in_addr_t*) (answer + 12);

	//change values we want to change
		*ipsrc = inet_addr (argv[1]);
		*portsrc = htons(atoi(argv[2]));
		*ipdst = inet_addr (argv[3]);
		*portdst = htons(atoi(argv[4]));
		*ansaddr = inet_addr(argv[6]);
		//dns query id
		*dnsid = htons(atoi(argv[7]));
		//udp header calc len
		*udplen = htons(8+12+querySize+16);
		//ip header calc len
		*iplen = htons(20+ntohs(*udplen));
	//

	//pack ip header
	char *current = datagram;
	copy(current,iphdr,20);
	current += 20;

	//pack udp header
	copy(current,udphdr,8);
	current += 8;

	//pack dns header
	copy(current,dnshdr,12);
	current += 12;

	//pack query
	copy(current,query,querySize);
	current += querySize;

	//pack answer
	copy(current,answer,16);
	current += 16;

	//IP_HDRINCL to tell the kernel that headers are included in the packet
	int one = 1;
	const int *val = &one;

	if (setsockopt (s, IPPROTO_IP, IP_HDRINCL, val, sizeof (one)) < 0){
		perror("Error setting IP_HDRINCL");
		exit(0);
	}

	if (sendto (s, datagram, ntohs(*iplen) , 0, (struct sockaddr *) &sin, sizeof (sin)) < 0){
		perror("Packet not sent.\n");
		exit(0);
	}else{
		printf ("Packet Sent.\n");
	}
	return;
}
