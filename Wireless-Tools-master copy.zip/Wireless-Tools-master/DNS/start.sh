#!/bin/bash
if [ $# == 2 ] 
then
  binaryFileName="FakeDNS-Etho"
  if [ ! -f $binaryFileName]
  then
    gcc FakeDNS-Etho.c -o $binaryFileName
  fi
  python ./LAN-DNS-Sniff-Reply.py $1 $2
else
  echo "Usage: ./start.sh <interface> <ipv4 addr>"
  echo "<interface> : interface to send packets out on. Doesn't matter much as ip & mac addr's are faked."
  echo "<ipv4 addr> : IP version 4 addr to reply to all DNS request with."
fi 
