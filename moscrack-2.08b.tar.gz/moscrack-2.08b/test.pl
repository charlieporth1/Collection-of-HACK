
use Data::Dumper;

open CMDLINE, "</proc/30932/cmdline";
my $cmdline = <CMDLINE>;
close CMDLINE;


my ($cmdName) = split("\0",$cmdline);
print $cmdName;
