#!/bin/sh

fail=0

echo TEST hash is SHA512
echo

echo "Test 1: Should find a match: core detect on"
echo test | ./dehasher '$6$NW0sE990$euXGI6U6w3dKJ5V3.w4dyczD6ThkLN5ueMViDZrqkNfxqCTNOfUe5CbcT/9SNQNwUfySQ6pADREV9wjLTYX3I/' > /dev/null

if test $? = 1 ; then 
	echo PASS
else 
	echo FAIL
	fail=1;
fi

echo
echo "Test 2: Should NOT find a match: core detect on"
echo wrong | ./dehasher '$6$NW0sE990$euXGI6U6w3dKJ5V3.w4dyczD6ThkLN5ueMViDZrqkNfxqCTNOfUe5CbcT/9SNQNwUfySQ6pADREV9wjLTYX3I/' > /dev/null

if test $? = 2 ; then
        echo PASS
else
        echo FAIL
        fail=1;
fi

echo
echo "Test 3: Should find a match: threads set to 1"
echo test | ./dehasher '$6$NW0sE990$euXGI6U6w3dKJ5V3.w4dyczD6ThkLN5ueMViDZrqkNfxqCTNOfUe5CbcT/9SNQNwUfySQ6pADREV9wjLTYX3I/' 1 > /dev/null

if test $? = 1 ; then
        echo PASS
else
        echo FAIL
        fail=1;
fi


echo
echo "Test 4: Should NOT find a match: threads set to 1"
echo wrong | ./dehasher '$6$NW0sE990$euXGI6U6w3dKJ5V3.w4dyczD6ThkLN5ueMViDZrqkNfxqCTNOfUe5CbcT/9SNQNwUfySQ6pADREV9wjLTYX3I/' 1 > /dev/null

if test $? = 2 ; then
        echo PASS
else
        echo FAIL
        fail=1;
fi

echo
if test $fail = 1 ; then 
	echo "Some tests failed"
else 
	echo "All tests passed"
fi

exit $fail
