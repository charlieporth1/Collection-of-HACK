#include <stdio.h>
#include <stdlib.h>

char *crypt();

int main(int argc, char *argv[]) {

  if(argc != 2) {
      fprintf(stderr, "usage: crypt password\n");
      exit(1);
  }

  printf("DES: %s\n",crypt(argv[1],"AA"));
  printf("MD5: %s\n",crypt(argv[1],"$1$AA$"));
  printf("Blowfish: %s\n",crypt(argv[1],"$2a$AA$"));
  printf("SHA256: %s\n",crypt(argv[1],"$5$AA$"));
  printf("SHA512: %s\n",crypt(argv[1],"$6$AA$"));
  exit(0);
}

