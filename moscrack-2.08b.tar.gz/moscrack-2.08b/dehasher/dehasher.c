/*
    Copyright 2011 Ryan Babchishin

    This file is part of Moscrack.

    Moscrack is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, version 3 of the License.

    Moscrack is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with Moscrack.  If not, see <http://www.gnu.org/licenses/>.
*/

// OS Specific
#ifdef BSD
#include <sys/param.h>
#include <sys/sysctl.h>
#else
#include <crypt.h>
#endif

#define _XOPEN_SOURCE

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <pthread.h>
#include <sys/signal.h>

#define MAX_THREADS 128

int numThreads;
pthread_t threads[MAX_THREADS];
pthread_mutex_t mutex;
char *hash;
int hashLen;
int total = 0;
int stop;


// Get number of CPU cores
int getNumCores() {
#ifdef WIN32
    SYSTEM_INFO sysinfo;
    GetSystemInfo(&sysinfo);
    return sysinfo.dwNumberOfProcessors;
#elif BSD
    int nm[2];
    size_t len = 4;
    uint32_t count;

    nm[0] = CTL_HW; nm[1] = HW_NCPU;
    sysctl(nm, 2, &count, &len, NULL, 0);

    if(count < 1) {
        nm[1] = HW_NCPU;
        sysctl(nm, 2, &count, &len, NULL, 0);
        if(count < 1) { count = 1; }
    }
    return count;
#else
    return sysconf(_SC_NPROCESSORS_ONLN);
#endif
}

// Worker thread
void *cryptThread(void *threadid)
{
	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);
   	long tid;
   	tid = (long)threadid;

	deCrypt(threadid);

   	pthread_exit(NULL);
	return;
}

// Read from stdin and crypt words
int deCrypt (long threadid) {
	char word[LINE_MAX];
	char result[128];
	
       // Read word list
        while (1) {
		pthread_mutex_lock(&mutex);
		if(stop) {
			pthread_mutex_unlock(&mutex);
			break;
		}

		if (fgets(word, LINE_MAX, stdin) == NULL) {
			stop = 2;
			pthread_mutex_unlock(&mutex);
			break;
		} 

		total = total + 1;
		pthread_mutex_unlock(&mutex);

                // remove newline
                int wordLen = strlen(word);
                if( word[wordLen-1] == '\n' )
                    word[wordLen-1] = 0;

		strcpy(result, crypt(word, hash));

            	//if(memcmp(result, hash, hashLen) == 0) {
            	if(strcmp(result, hash) == 0) {
                        printf("Match: \'%s\'\n", word, hash);
			pthread_mutex_lock(&mutex);
			stop = 1; // tell threads to stop
			pthread_mutex_unlock(&mutex);
			break;
                }

        }

	return;
}

// Thread to print status/speed
void *outputStatus (void *threadid) {
	int duration;
	time_t start = time(NULL);
	int speed;

	pthread_setcancelstate(PTHREAD_CANCEL_ENABLE, NULL);

        while (1) {
			sleep(5);
                	duration = time(NULL) - start;
			if(duration < 1)
				duration = 1;
			pthread_mutex_lock(&mutex);
                	speed = total / duration;
                	printf ("%d k/s total = %d\n", speed, total);
			pthread_mutex_unlock(&mutex);
        }

        pthread_exit(NULL);
        return;

}

// Test if a string is numeric
int isNumeric(char *string) {
	int numeric = 1;

	if(string == NULL) return(0);

	int len = strlen(string);	
	int i;
	for(i=0;i<len;i++) {
		if(! isdigit(string[i])) {
			numeric = 0;	
			break;
		}
	}

	return(numeric);
}

void help(void) {
	printf("Usage: dehasher <$id$salt$encrypted> <threads> < wordlist.txt\n");
	exit(255);
}


int main ( int argc, char *argv[] ) {

	// Print help and exit
	if(argv[1] == NULL) 
		help();
	else if (strcmp(argv[1],"--help") == 0) 
		help();

        hash = argv[1];
        hashLen = strlen(hash);
        if( hash[hashLen-1] != 0 )
                hash[hashLen] = 0;


	printf("Hash: %s %d\n", hash, hashLen);

	if (isNumeric(argv[2])) {
		int cores = atoi(argv[2]);
		if(cores > 0 && cores <= MAX_THREADS) 
			numThreads = cores + 1;
	} 

	if(numThreads < 1) {
		numThreads = getNumCores() + 1;
		printf("Cores detected: %d\n", numThreads - 1);
	} 

	// Timer
	time_t start = time(NULL);
	int duration;

	printf("Creating %d worker threads\n", numThreads - 1);

	// create threads
        //threads[numThreads];
	pthread_mutex_init(&mutex, NULL);
 
   	int rc;
   	long t;
   	for(t=0; t<(numThreads - 1); t++){
      		rc = pthread_create(&threads[t], NULL, cryptThread, (void *)t);
      			if (rc) {
         		printf("ERROR: return code from pthread_create() is %d\n", rc);
         		exit(-1);
      		}
   	}

	// Create status output thread
	t = numThreads - 1;
	rc = pthread_create(&threads[t], NULL, outputStatus, (void *)t);
        	if (rc) {
                        printf("ERROR: return code from pthread_create() is %d\n", rc);
                        exit(-1);
		}

	// Wait for threads to exit
	for(t=0; t<numThreads - 1; t++){
		pthread_join(threads[t], NULL);
	}

	// Determine performance
        duration = time(NULL) - start;
        if(duration < 1)
                duration = 1;
        int speed = total / duration;


	// Cancel the status thread
	int statusTid = numThreads - 1;
	pthread_cancel(threads[statusTid]); // status thread
	pthread_join(threads[statusTid], NULL);



	// Exit
	if(stop != 1) printf ("No match found\n");
        printf ("Speed: %d k/s\n", speed);
	pthread_mutex_destroy(&mutex);
	exit(stop);
}

