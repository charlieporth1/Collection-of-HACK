#!/bin/sh	

sh scripts/version
autoreconf --install --verbose
