module.exports = {
    Airport: require('./lib/airport').Airport
};