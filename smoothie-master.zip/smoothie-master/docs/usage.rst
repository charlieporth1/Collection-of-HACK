=====
Usage
=====

To use smoothie in a project::

    import smoothie
