.. highlight:: shell

============
Installation
============

At the command line::

    $ easy_install smoothie

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv smoothie
    $ pip install smoothie
