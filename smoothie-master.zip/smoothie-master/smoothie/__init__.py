# -*- coding: utf-8 -*-

__author__ = 'David Francos Cuartero'
__email__ = 'me@davidfrancos.net'
__version__ = '0.1.0'
