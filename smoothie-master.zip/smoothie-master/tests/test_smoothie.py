#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
test_smoothie
----------------------------------

Tests for `smoothie` module.
"""

import unittest

from smoothie import smoothie


class TestSmoothie(unittest.TestCase):

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def test_000_something(self):
        pass


if __name__ == '__main__':
    import sys
    sys.exit(unittest.main())
