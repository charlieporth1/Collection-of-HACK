===============================
smoothie
===============================

.. image:: https://img.shields.io/pypi/v/smoothie.svg
        :target: https://pypi.python.org/pypi/smoothie

.. image:: https://img.shields.io/travis/XayOn/smoothie.svg
        :target: https://travis-ci.org/XayOn/smoothie

.. image:: https://readthedocs.org/projects/smoothie/badge/?version=latest
        :target: https://readthedocs.org/projects/smoothie/?badge=latest
        :alt: Documentation Status


Wireless smoothie. Simple and usable web interface for common wireless attacks

* Free software: ISC license
* Documentation: https://smoothie.readthedocs.org.

Features
--------

* TODO

Credits
---------

This package was created with Cookiecutter_ and the `audreyr/cookiecutter-pypackage`_ project template.

.. _Cookiecutter: https://github.com/audreyr/cookiecutter
.. _`audreyr/cookiecutter-pypackage`: https://github.com/audreyr/cookiecutter-pypackage

Current state
-------------

This is a totally dummy project in its current state.
It really does nothing useful (yet looks cool).

It actually requires you to start:

    - A few (at least 2) rq workers on the "plugins" queue (as root).
    - smoothie

And, of course, having mongodb and redis running.
Access it at port 8080 (not yet configurable).

.. image:: /../master/docs/smoothie.gif?raw=true

