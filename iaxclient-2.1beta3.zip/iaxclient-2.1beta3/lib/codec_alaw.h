/*
 * iaxclient: a cross-platform IAX softphone library
 *
 * Copyrights:
 * Copyright (C) 2004 Cyril VELTER
 *
 * Contributors:
 * Cyril VELTER <cyril.velter@metadys.com>
 *
 * This program is free software, distributed under the terms of
 * the GNU Lesser (Library) General Public License.
 */

struct iaxc_audio_codec *codec_audio_alaw_new();
