# Wificracker
This is a small python script to help you crack nearby wireless networks in no time, it uses `aircrack-ng` suite of tools to brake into the desired wifi

### Requirements
- [aircrack-ng](https://www.aircrack-ng.org/)
- [termcolor](https://pypi.python.org/pypi/termcolor)
