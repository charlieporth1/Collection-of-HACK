/* Serial prototypes for iWar */

extern void m_savestate( int);
extern void m_restorestate( int);
extern void m_setparms( int, char *, char *, char *, int, int);
extern void m_nohang( int);
extern void m_hupcl( int, int);
extern void m_flush( int);
extern void m_break( int); 
extern void m_dtrtoggle( int, int ); 
