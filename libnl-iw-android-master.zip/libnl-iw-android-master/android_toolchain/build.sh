#搜索到NDK-BUILD目录
../../android-ndk-r9d/ndk-build
