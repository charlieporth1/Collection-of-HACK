#!/bin/sh
aclocal
autoheader
automake -ac
autoconf
