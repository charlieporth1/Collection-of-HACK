# THIS IS NOT THE OFICIAL RELEASE YET

# NOTICE: THIS TOOL HAS BEEN WRITTEN FOR EDUCATIONAL PURPOSES ONLY!

## History

This version is *based* on an old project that I did some time ago (may be 2009/2010...)

## Farlo-NG

Tool to crack WEP/WPA/WPA2 wireless networks in realtime

## How does it works?

This tool works by generating and testing all possible default passwords for each wireless AP based on ESSID and BSSID.
Also you can specify a custom password dictionary to try to crack the network when the default password has been changed.

## Default passwords?

Yes, the information has been taken from tools like wlandecrypter, jazzteldecrypter, decsagem, wlan4x....

If I have not mentioned you under "Credits", let me know to fix it.

## WPA/WPA2

Not so good... Actually, network cracking (password verifying :P) only works with WEP encrypted networks, BUT when a WPA/WPA2 network is found, this tool will save all the generated passwords into a single file in the same path.

## What's the purpose of 'patterns.xml' file?

This file specifies wich algorithm must be applied to each network (may be many algorithms for the same network pattern).

## Credits

Thanks to buckynet *dudux and nir0zmel0N and many others for disclousure their wireless security researches
