# Dckuino.js Teensy 3.2 MOD
This is a modification from the original Dckuino.js for working properly with Teensy 3.2. Modifications:

(1) The Teensy LED starts blinking when it finishes the payload execution.

(2) Incompatibilities with Teensy 3.2 were fixed.

(3) 3.5 seconds added before every payload (This is for ensuring that the payload will run properly).
