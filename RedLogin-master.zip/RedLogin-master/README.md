# RedLogin
Red Login: SSH Brute-force Tools

![alt text](https://github.com/ParsingTeam/RedLogin/raw/master/ScreenShot.jpg) 

Features:

+ High speed and precision
+ CLI ( Console  based )
+ Run the arbitrary command after the attack is successful ( Default 'Uname -a' )
+ Telegram messanger support for sending reports via bot API

Usage: 

Redlogin.exe <Targetlist.txt> <Userlist.txt> <Passlist.txt> (Optional) —telegram <BotToken> <ChatID>

<Targetlist.txt> ==> List of targets ip list

<Userlist.txt> ==> List of usernames want to test

<Passlist.txt>  ==> List of passwords want to test

<BotToken> ==> Telegram bot token via @BotFather
  
<ChatID> ==> Telegram chatid via @userinfobot
  
# Thanks to
- JeJe Plus
- Rojhelat

# Report bugs
Telegram : @N3verlove
