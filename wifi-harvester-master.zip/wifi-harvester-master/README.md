WiFi Harvester
~~~~~~~~~~~~~~~~


This is a beta release of WiFi Harvester and developer provide no support on problem faced on non Kali Linux OS. This script may be more applicable for pentester and those with at least some knowledge on wireless penetration testing. 


Similar to WIDS, this script required aircrack-ng suite, python 2.7, tshark to be installed on the system. To save hassle on all these issue, please use this script on Kali Linux/Backtrack as required applications already preinstalled. 


Simply download wifiharvester.py and run the application.


Probing.sh is just an old probing bash script created years back. 
