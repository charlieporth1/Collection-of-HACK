#!/usr/bin/env python
# -*- coding: utf-8 -*-

__year__    = [2016, 2017];
__status__  = "Stable";
__contact__ = "jacobsin1996@gmail.com";


def main():
        # This will be an update script that can be called to auto update boop
        # Steps:
            # Delete current dirs.
            # Download boop from github
            # Install script
            # Pip requirements
        # Problems to overcome:
            # Deleting the dir while inside of it...
            # Solution?:
                # Create a secondary script elsewhere call it as this one exists
                # Second script can delete this dir and install over it...

        # Time frame:
            # Complete by end of july or by birthday.
        print("This script is being built. ");
        print("Thanks for your patience.");
        return 0;

main();
