
# Python-iw

python-wrapper for `iw scan` with linear parser (not finished yet)