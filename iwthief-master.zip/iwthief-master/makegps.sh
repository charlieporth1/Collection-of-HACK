#!/bin/bash

gcc -lm -lpgs -g -o gpstest gpstest.c
