

#include <assert.h>

#ifdef __cplusplus
extern "C"
#endif
char strlcat();

int main() {
#if defined (__stub_strlcat) || defined (__stub___strlcat)
  fail fail fail
#else
  strlcat();
#endif

  return 0;
}
