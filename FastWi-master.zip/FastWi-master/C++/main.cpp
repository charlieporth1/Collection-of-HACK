#include <iostream>
#include "aircrack/aireplay.c"

using namespace std;

int main()
{
    cout << "Hello world!" << endl;
    return 0;
}
