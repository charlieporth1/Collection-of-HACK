# FastWi
A automatet Wireless Kicking Tool

It kicks People out of WiFi networks, thats all.
