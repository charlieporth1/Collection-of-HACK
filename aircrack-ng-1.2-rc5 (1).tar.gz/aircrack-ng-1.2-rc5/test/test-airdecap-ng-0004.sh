#!/bin/sh

set -ef

"${abs_srcdir}/test-airdecap-ng.sh" "${top_builddir}/src"

exit 0

