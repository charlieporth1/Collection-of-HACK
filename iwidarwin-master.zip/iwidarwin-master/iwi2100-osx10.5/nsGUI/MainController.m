#import "MainController.h"

@implementation MainController

- (IBAction)Cancel:(id)sender
{
}

- (IBAction)Connect:(id)sender
{
}

- (IBAction)LEDAction:(id)sender
{
}

- (IBAction)ModeACtion:(id)sender
{
}

- (IBAction)NetworkAction:(id)sender
{
}

- (IBAction)PowerAction:(id)sender
{
}

- (IBAction)RefreshAction:(id)sender
{
}

@end
