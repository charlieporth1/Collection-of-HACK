make CC=arm-fsl-linux-gnueabi-gcc
