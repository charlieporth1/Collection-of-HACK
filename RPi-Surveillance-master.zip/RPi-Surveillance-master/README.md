RPi Surveillance
==============

<h3>Caduceus RPi Surveillance</h3>
<p>During the second term of the Software Engineering & Managment program at the university of Gothenburg team Caduceus created a small surveillance system by using a Raspberry Pi + Raspicam and a basic webinterface.</p>
