# wifi-probe

Display the SSID probes of nearby wireless devices. Useful in wireless security awareness projects.

![](wifi-probe.gif)
