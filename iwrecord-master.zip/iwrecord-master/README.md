# iwrecord [![Build Status][1]][2]

A tool to record wireless traffic.

### License

This work is released under the [GNU General Public License 3.0][3].

[1]: https://travis-ci.org/jmlemetayer/iwrecord.png?branch=master
[2]: https://travis-ci.org/jmlemetayer/iwrecord
[3]: http://www.gnu.org/licenses/gpl-3.0.html
