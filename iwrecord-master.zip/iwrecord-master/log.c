/*
 **  Copyright(C) 2013 Jean-Marie Lemetayer <jeanmarie.lemetayer@gmail.com>
 **
 **  This program is free software: you can redistribute it and/or modify it
 **  under the terms of the GNU General Public License as published by the Free
 **  Software Foundation, either version 3 of the License, or (at your option)
 **  any later version.
 **
 **  This program is distributed in the hope that it will be useful, but WITHOUT
 **  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 **  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 **  more details.
 **
 **  You should have received a copy of the GNU General Public License along
 **  with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "log.h"

#include <stdarg.h>
#include <stdlib.h>

unsigned char loglevel = 0;

void printlog(FILE *stream, const char *prefix, const char* format, ...)
{
	va_list ap;
	char *newformat = NULL;

	if((newformat = malloc(strlen(prefix) + strlen(format) + 2)) == NULL)
		return;

	sprintf(newformat, "%s%s\n", prefix, format);

	va_start(ap, format);
	vfprintf(stream, newformat, ap);
	va_end(ap);

	free(newformat);
}
