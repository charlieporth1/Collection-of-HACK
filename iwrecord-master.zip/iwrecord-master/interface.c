/*
 **  Copyright(C) 2013 Jean-Marie Lemetayer <jeanmarie.lemetayer@gmail.com>
 **
 **  This program is free software: you can redistribute it and/or modify it
 **  under the terms of the GNU General Public License as published by the Free
 **  Software Foundation, either version 3 of the License, or (at your option)
 **  any later version.
 **
 **  This program is distributed in the hope that it will be useful, but WITHOUT
 **  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 **  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 **  more details.
 **
 **  You should have received a copy of the GNU General Public License along
 **  with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "interface.h"
#include "log.h"

static int get_flags(int skfd, const char *ifname, uint16_t *flags)
{
	struct ifreq ifr;

	strncpy(ifr.ifr_name, ifname, IFNAMSIZ - 1);
	ifr.ifr_name[IFNAMSIZ - 1] = '\0';

	if(ioctl(skfd, SIOCGIFFLAGS, &ifr) < 0) {
		edebug("Failed to get interface flags");
		return -1;
	}

	*flags = ifr.ifr_flags;
	return 0;
}

static int set_flags(int skfd, char *ifname, uint16_t *flags)
{
	struct ifreq ifr;

	strncpy(ifr.ifr_name, ifname, IFNAMSIZ - 1);
	ifr.ifr_name[IFNAMSIZ - 1] = '\0';
	ifr.ifr_flags = *flags;

	if(ioctl(skfd, SIOCSIFFLAGS, &ifr) < 0) {
		edebug("Failed to set interface flags");
		return -1;
	}

	return 0;
}

static int have_capa(uint32_t *event, int capa)
{
	int idx = IW_EVENT_CAPA_INDEX(capa);
	int mask = IW_EVENT_CAPA_MASK(capa);
	if(event[idx] & mask)
		return 0;

	return -1;
}

static int set_up(int skfd, wif_t *wif)
{
	uint16_t flags = 0;

	if(get_flags(skfd, wif->name, &flags) < 0) {
		debug("Failed to set interface up");
		return -1;
	}

	flags |= (IFF_UP | IFF_RUNNING);

	if(set_flags(skfd, wif->name, &flags) < 0) {
		debug("Failed to set interface up");
		return -1;
	}

	return 0;
}

static int set_down(int skfd, wif_t *wif)
{
	uint16_t flags = 0;

	if(get_flags(skfd, wif->name, &flags) < 0) {
		debug("Failed to set interface down");
		return -1;
	}

	flags &= ~IFF_UP;

	if(set_flags(skfd, wif->name, &flags) < 0) {
		debug("Failed to set interface down");
		return -1;
	}

	return 0;
}

static int have_capa_mode(wif_t *wif)
{
	return have_capa(wif->cap.event, SIOCSIWMODE);
}

static int have_capa_freq(wif_t *wif)
{
	return have_capa(wif->cap.event, SIOCSIWFREQ);
}

static int have_channel(wif_t *wif, uint8_t channel)
{
	int i;

	for(i = 0; i < wif->cap.num_frequency; i++)
		if(wif->cap.freq[i].i == channel)
			return 0;

	return -1;
}

static int set_mode(int skfd, wif_t *wif, uint8_t mode)
{
	struct iwreq wrq;

	wrq.u.mode = mode;

	if(iw_set_ext(skfd, wif->name, SIOCSIWMODE, &wrq) < 0) {
		edebug("Failed to set mode");
		return -1;
	}

	return 0;
}

static int set_freq(int skfd, wif_t *wif, double freq, uint8_t flags)
{
	struct iwreq wrq;

	iw_float2freq(freq, &(wrq.u.freq));
	wrq.u.freq.flags = flags;

	if(iw_set_ext(skfd, wif->name, SIOCSIWFREQ, &wrq) < 0) {
		edebug("Failed to set frequency");
		return -1;
	}

	return 0;
}

static int fill(int skfd, char *ifname,
		char **argv, int argc __attribute__ ((unused)))
{
	wif_t **list = (wif_t**)argv;
	wif_t *new;

	struct iwreq wrq;

	struct iw_range range;
	memset(&range, 0, sizeof(struct iw_range));

	/* Check if the interface have wireless extension */
	if(iw_get_ext(skfd, ifname, SIOCGIWNAME, &wrq) < 0) {
		edebug("Failed to check wireless extension");
		return -1;
	}

	/* Create a new item in the list */
	if((new = malloc(sizeof(wif_t))) == NULL) {
		eerror("Failed to allocate memory");
		return -1;
	}

	/* Fill next */
	new->next = *list;

	/* Fill name */
	strncpy(new->name, ifname, IFNAMSIZ - 1);
	new->name[IFNAMSIZ - 1] = '\0';

	/* Get flags */
	if(get_flags(skfd, ifname, &new->flags) < 0) {
		ewarning("Failed to get interface flags");
		free(new);
		return -1;
	}

	/* Get range info */
	if(iw_get_range_info(skfd, ifname, &range) < 0) {
		ewarning("Failed to get range info");
		free(new);
		return -1;
	}

	/* Fill capabilities */
	memcpy(new->cap.event, range.event_capa, 6 * sizeof(uint32_t));
	new->cap.num_frequency = range.num_frequency;
	memcpy(new->cap.freq, range.freq,
			IW_MAX_FREQUENCIES * sizeof(struct iw_freq));

	/* Fill channel */
	if(iw_get_ext(skfd, ifname, SIOCGIWFREQ, &wrq) >= 0) {
		new->channel = iw_freq_to_channel(iw_freq2float(&wrq.u.freq), &range);
		new->channel_flags = wrq.u.freq.flags;
		new->has_channel = 1;
	}

	/* Fill operation mode */
	if(iw_get_ext(skfd, ifname, SIOCGIWMODE, &wrq) >= 0) {
		new->mode = (wrq.u.mode < IW_NUM_OPER_MODE) ? \
					wrq.u.mode : IW_NUM_OPER_MODE;
		new->has_mode = 1;
	}

	/* Add the new item into the list */
	*list = new;

	return 0;
}

static void print_info(wif_t *wif)
{
	char str_channel[32] = "";
	char str_mode[32] = "";

	if(wif->has_channel)
		sprintf(str_channel, " on channel %d", wif->channel);

	if(wif->has_mode)
		sprintf(str_mode, " in mode %s", iw_operation_mode[wif->mode]);

	info("%s is %s%s%s%s", wif->name,
			(wif->flags & IFF_UP) ? "up" : "down",
			(wif->flags & IFF_RUNNING) ? " and running" : "",
			str_channel, str_mode);
}

int wif_select(global_t *g)
{
	/* Get all the wireless interfaces */
	iw_enum_devices(g->skfd, &fill, (char**)&g->wif_list, 1);

	/* Select an interface */
	for(g->wif = g->wif_list; g->wif != NULL; g->wif = g->wif->next) {

		/* If the user specified an interface */
		if((g->interface != NULL) && (strcmp(g->interface, g->wif->name) == 0)) {

			/* The interface must be able to set mode */
			if(have_capa_mode(g->wif) < 0) {
				error("%s is unable to set operation mode", g->wif->name);
				return -1;
			}

			/* The interface must be able to set frequency */
			if(have_capa_freq(g->wif) < 0) {
				error("%s is unable to set frequency", g->wif->name);
				return -1;
			}

			/* The interface must have the channel available */
			if(have_channel(g->wif, g->channel) < 0) {
				error("%s is unable to record on channel %d",
						g->wif->name, g->channel);
				return -1;
			}

			break;

		/* If the user doesn't specified an interface */
		} else if(g->interface == NULL) {

			/* The interface must be able to set mode */
			if(have_capa_mode(g->wif) < 0) {
				info("%s is unable to set operation mode - skip", g->wif->name);
				continue;
			}

			/* The interface must be able to set frequency */
			if(have_capa_freq(g->wif) < 0) {
				info("%s is unable to set frequency - skip", g->wif->name);
				continue;
			}

			/* The interface must have the channel available */
			if(have_channel(g->wif, g->channel) < 0) {
				info("%s is unable to record on channel %d - skip",
						g->wif->name, g->channel);
				continue;
			}

			break;
		}
	}

	/* An interface is mandatory */
	if(g->wif == NULL)
		return -1;

	/* Print interface informations */
	notice("Using %s on channel %d", g->wif->name, g->channel);
	print_info(g->wif);

	return 0;
}

void wif_free(global_t *g)
{
	wif_t *item, *next;
	for(item = g->wif_list; item != NULL; item = next) {
		next = item->next;
		free(item);
	}
}

int wif_config(global_t *g)
{
	/* Set interface down */
	if(set_down(g->skfd, g->wif) < 0) {
		eerror("Failed to set interface down");
		return -1;
	}

	/* Set interface in monitor mode */
	if(set_mode(g->skfd, g->wif, IW_MODE_MONITOR) < 0) {
		eerror("Failed to set interface in monitor mode");
		return -1;
	}

	/* Set interface channel */
	if(set_freq(g->skfd, g->wif, (double)g->channel,
				IW_FREQ_FIXED) < 0) {

		/* If the driver is not ready, try with interface up */
		if(errno != ENETDOWN) {
			eerror("Failed to set interface channel");
			return -1;
		}

		/* Set interface up */
		if(set_up(g->skfd, g->wif) < 0) {
			eerror("Failed to set interface up");
			return -1;
		}

		/* Set interface channel */
		if(set_freq(g->skfd, g->wif, (double)g->channel,
					IW_FREQ_FIXED) < 0) {
			eerror("Failed to set interface channel");
			return -1;
		}

	} else {

		/* Set interface up */
		if(set_up(g->skfd, g->wif) < 0) {
			eerror("Failed to set interface up");
			return -1;
		}
	}

	return 0;
}

int wif_restore(global_t *g)
{
	/* Set interface down */
	if(set_down(g->skfd, g->wif) < 0) {
		eerror("Failed to set interface down");
		return -1;
	}

	/* Restore interface mode */
	if(g->wif->has_mode) {
		if(set_mode(g->skfd, g->wif, g->wif->mode) < 0) {
			eerror("Failed to restore interface mode");
			return -1;
		}
	}

	/* Restore interface channel */
	if(g->wif->has_channel) {
		if(set_freq(g->skfd, g->wif, (double)g->wif->channel,
					g->wif->channel_flags) < 0) {

			/* If the driver is not ready, try with interface up */
			if(errno != ENETDOWN) {
				eerror("Failed to restore interface channel");
				return -1;
			}

			/* Set the interface up */
			if(set_up(g->skfd, g->wif) < 0) {
				eerror("Failed to set interface up");
				return -1;
			}

			/* Restore interface channel */
			if(set_freq(g->skfd, g->wif, (double)g->wif->channel,
						g->wif->channel_flags) < 0) {
				eerror("Failed to set interface channel");
				return -1;
			}
		}
	}

	/* Restore interface flags */
	if(set_flags(g->skfd, g->wif->name, &g->wif->flags) < 0) {
		eerror("Failed to restore flags");
		return -1;
	}

	return 0;
}
