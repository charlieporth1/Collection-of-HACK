/*
 **  Copyright(C) 2013 Jean-Marie Lemetayer <jeanmarie.lemetayer@gmail.com>
 **
 **  This program is free software: you can redistribute it and/or modify it
 **  under the terms of the GNU General Public License as published by the Free
 **  Software Foundation, either version 3 of the License, or (at your option)
 **  any later version.
 **
 **  This program is distributed in the hope that it will be useful, but WITHOUT
 **  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 **  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 **  more details.
 **
 **  You should have received a copy of the GNU General Public License along
 **  with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "signal.h"

#include <stdlib.h>

#include "log.h"

typedef struct signal {
	struct signal *next;		/* The next signal structure */
	int sig;					/* The signal */
	signal_handler_t handler;	/* The handler */
	void *data;					/* The data */
} signal_t;

static signal_t *signals;		/* The list of register signals */

static void signal_handler(int sig)
{
	signal_t *signal;

	debug("Receive signal (%d)", sig);

	for(signal = signals; signal != NULL; signal = signal->next) {
		if(signal->sig == sig) {
			(*signal->handler)(signal->data);
			break;
		}
	}
}

int signal_register(int sig, signal_handler_t handler, void *data)
{
	signal_t *new;

	if((new = malloc(sizeof(signal_t))) == NULL) {
		eerror("Failed to add signal");
		return -1;
	}

	new->next = signals;
	new->sig = sig;
	new->handler = handler;
	new->data = data;

	if(signal(sig, signal_handler) == SIG_ERR) {
		eerror("Failed to register signal");
		free(new);
		return -1;
	}

	signals = new;

	return 0;
}

void signal_free(void)
{
	signal_t *item, *next;
	for(item = signals; item != NULL; item = next) {
		next = item->next;
		free(item);
	}
}
