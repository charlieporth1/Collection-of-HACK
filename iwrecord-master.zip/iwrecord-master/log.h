/*
 **  Copyright(C) 2013 Jean-Marie Lemetayer <jeanmarie.lemetayer@gmail.com>
 **
 **  This program is free software: you can redistribute it and/or modify it
 **  under the terms of the GNU General Public License as published by the Free
 **  Software Foundation, either version 3 of the License, or (at your option)
 **  any later version.
 **
 **  This program is distributed in the hope that it will be useful, but WITHOUT
 **  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 **  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 **  more details.
 **
 **  You should have received a copy of the GNU General Public License along
 **  with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __LOG__
#define __LOG__

#include <errno.h>
#include <stdio.h>
#include <string.h>

/* Define the log levels */
#define LOG_CRIT		(1 << 0)
#define LOG_ERR			(1 << 1)
#define LOG_WARNING		(1 << 2)
#define LOG_NOTICE		(1 << 3)
#define LOG_INFO		(1 << 4)

/* Public variable to store the log levels */
extern unsigned char loglevel;

/* Private printlog function */
void printlog(FILE *stream, const char *prefix, const char* format, ...);

/* Log functions */
#define info(format, ...)		if(loglevel & LOG_INFO) \
	printlog(stderr, "I/ ", format, ##__VA_ARGS__)

#define notice(format, ...)		if(loglevel & LOG_NOTICE) \
	printlog(stderr, "N/ ", format, ##__VA_ARGS__)

#define warning(format, ...)	if(loglevel & LOG_WARNING) \
	printlog(stderr, "W/ ", format, ##__VA_ARGS__)

#define error(format, ...)		if(loglevel & LOG_ERR) \
	printlog(stderr, "E/ ", format, ##__VA_ARGS__)

#define critical(format, ...)	if(loglevel & LOG_CRIT) \
	printlog(stderr, "C/ ", format, ##__VA_ARGS__)

/* Log functions with errno */
#define einfo(string)		info("%s: %s", string, strerror(errno))
#define enotice(string)		notice("%s: %s", string, strerror(errno))
#define ewarning(string)	warning("%s: %s", string, strerror(errno))
#define eerror(string)		error("%s: %s", string, strerror(errno))
#define ecritical(string)	critical("%s: %s", string, strerror(errno))

/* Debug functions */
#ifdef CONFIG_DEBUG
#define debug(format, ...)	printlog(stderr, "D/ %s:%d ", \
		format, __FILE__, __LINE__, ##__VA_ARGS__)
#define edebug(string)		debug("%s: %s", string, strerror(errno))
#else
#define debug(format, ...)
#define edebug(string)
#endif

#endif /* __LOG__ */
