/*
 **  Copyright(C) 2013 Jean-Marie Lemetayer <jeanmarie.lemetayer@gmail.com>
 **
 **  This program is free software: you can redistribute it and/or modify it
 **  under the terms of the GNU General Public License as published by the Free
 **  Software Foundation, either version 3 of the License, or (at your option)
 **  any later version.
 **
 **  This program is distributed in the hope that it will be useful, but WITHOUT
 **  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 **  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 **  more details.
 **
 **  You should have received a copy of the GNU General Public License along
 **  with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <getopt.h>
#include <iwlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>

#include "config.h"
#include "interface.h"
#include "global.h"
#include "log.h"
#include "signal.h"

static void usage(void)
{
	fprintf(stderr,
			"Usage: " PACKAGE_NAME " [OPTIONS] CHANNEL\n"
			PACKAGE_DESCRIPTION "\n\n"
			"-i, --interface INTF    Use the specified interface.\n"
			"-o, --output FILE       Record in the specified file.\n"
			"-v, --verbose           Produce verbose output.\n"
			"    --version           Display version.\n"
			"    --help              Display this help screen.\n\n"
			PACKAGE_NAME " home page: <" PACKAGE_URL ">\n"
			"Report " PACKAGE_NAME
			" bugs to <" PACKAGE_BUGREPORT ">\n");
}

static void terminate(void *data)
{
	global_t *g = (global_t*)data;

	/* Restore the wireless interface */
	if(wif_restore(g) < 0)
		error("Failed to restore the wireless interface");

	/* Close the socket */
	if(close(g->skfd) < 0)
		eerror("Failed to close socket");

	/* Free the wireless interfaces list */
	wif_free(g);

	/* Free the signals list */
	signal_free();

	exit(EXIT_SUCCESS);
}

int main(int argc, char** argv)
{
	int option;
	int option_index = 0;

	global_t global;
	global_t *g = &global;

	/* Initialize global structure */
	memset(g, 0, sizeof(global_t));

	/* Default log level */
	loglevel = LOG_CRIT | LOG_ERR | LOG_WARNING;

	/* getopt_long options */
	static struct option long_options[] = {
		{"version", 	no_argument,		NULL,  0 },
		{"help",		no_argument,		NULL,  0 },
		{"interface",	required_argument,	NULL, 'i'},
		{"output",		required_argument,	NULL, 'o'},
		{"verbose", 	no_argument,		NULL, 'v'},
		{NULL,			0,					NULL,  0 }
	};

	/* Check for options */
	while((option = getopt_long(argc, argv, "i:o:v0",
					long_options, &option_index)) != EOF) {
		switch(option) {
			case 'i':
				g->interface = optarg;
				break;
			case 'o':
				g->output = optarg;
				break;
			case 'v':
				loglevel = LOG_CRIT | LOG_ERR | LOG_WARNING | \
						   LOG_NOTICE | LOG_INFO;
				break;
			case 0:
				if(option_index == 0) {
					fprintf(stdout, "%s\n", PACKAGE_STRING);
					exit(EXIT_SUCCESS);
				}
			case '?':
				usage();
				exit(EXIT_FAILURE);
				break;
		}
	}

	if(optind >= argc) {
		usage();
		exit(EXIT_FAILURE);
	}

	/* Get the channel and check if it's a valid number */
	if(((g->channel = atoi(argv[optind])) == 0) && (argv[optind][0] != '0')) {
		critical("'%s' is not a valid number", argv[optind]);
		exit(EXIT_FAILURE);
	}

	/* Register the SIGINT signal */
	if(signal_register(SIGINT, terminate, g) < 0) {
		critical("Failed to register SIGINT");
		exit(EXIT_FAILURE);
	}

	/* Register the SIGTERM signal */
	if(signal_register(SIGTERM, terminate, g) < 0) {
		critical("Failed to register SIGTERM");
		exit(EXIT_FAILURE);
	}

	/* Open the kernel socket */
	if((g->skfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
		ecritical("Failed to open socket");
		exit(EXIT_FAILURE);
	}

	/* Select a wireless interface */
	if(wif_select(g) < 0) {
		critical("Failed to select a wireless interface");
		exit(EXIT_FAILURE);
	}

	/* Configure the interface for recording */
	if(wif_config(g) < 0) {
		critical("Failed to configure the wireless interface");
		exit(EXIT_FAILURE);
	}

	info("Output: %s", g->output ? g->output : "stdout");

	/* The big loop */
	while(1) sleep(1);

	/* Should never happen */
	exit(EXIT_FAILURE);
}
