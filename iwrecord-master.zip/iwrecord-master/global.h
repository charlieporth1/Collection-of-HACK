/*
 **  Copyright(C) 2013 Jean-Marie Lemetayer <jeanmarie.lemetayer@gmail.com>
 **
 **  This program is free software: you can redistribute it and/or modify it
 **  under the terms of the GNU General Public License as published by the Free
 **  Software Foundation, either version 3 of the License, or (at your option)
 **  any later version.
 **
 **  This program is distributed in the hope that it will be useful, but WITHOUT
 **  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 **  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 **  more details.
 **
 **  You should have received a copy of the GNU General Public License along
 **  with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __GLOBAL__
#define __GLOBAL__

#include <stdint.h>

#include "interface.h"

typedef struct {
	char *interface;	/* The requested interface */
	char *output;		/* The requested output */
	uint8_t channel;	/* The requested channel */
	int skfd;			/* The socket file descriptor */
	wif_t *wif_list;	/* The list of the wireless interfaces */
	wif_t *wif;			/* The current wireless interface */
} global_t;

#endif /* __GLOBAL__ */
