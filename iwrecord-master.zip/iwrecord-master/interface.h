/*
 **  Copyright(C) 2013 Jean-Marie Lemetayer <jeanmarie.lemetayer@gmail.com>
 **
 **  This program is free software: you can redistribute it and/or modify it
 **  under the terms of the GNU General Public License as published by the Free
 **  Software Foundation, either version 3 of the License, or (at your option)
 **  any later version.
 **
 **  This program is distributed in the hope that it will be useful, but WITHOUT
 **  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 **  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 **  more details.
 **
 **  You should have received a copy of the GNU General Public License along
 **  with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __INTERFACE__
#define __INTERFACE__

#include <iwlib.h>
#include <stdint.h>

/* struct wif_cap:
 * Store the capabilities of the wireless interface */

struct wif_cap {
	uint32_t		event[6];					/* Event capabilities */
	uint8_t			num_frequency;				/* Number of frequencies */
	struct iw_freq	freq[IW_MAX_FREQUENCIES];	/* Frequency list */
};

/* struct wif:
 * Store all the informations that we need about the wireless interface */

typedef struct wif {
	struct wif		*next;						/* Next interface */
	char			name[IFNAMSIZ];				/* Interface name */
	struct wif_cap	cap;						/* Interface capabilities */
	uint16_t		flags;						/* Flags */
	uint8_t			has_channel;
	uint8_t			channel;					/* Channel */
	uint8_t			channel_flags;
	uint8_t			has_mode;
	uint8_t			mode;						/* Operation mode */
} wif_t;

#include "global.h"

/* Select a wireless interface */
int wif_select(global_t *g);

/* Free the wireless interface list */
void wif_free(global_t *g);

/* Configure the interface for recording */
int wif_config(global_t *g);

/* Restore the interface */
int wif_restore(global_t *g);

#endif /* __INTERFACE__ */
