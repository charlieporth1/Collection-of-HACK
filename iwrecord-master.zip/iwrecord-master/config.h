/*
 **  Copyright(C) 2013 Jean-Marie Lemetayer <jeanmarie.lemetayer@gmail.com>
 **
 **  This program is free software: you can redistribute it and/or modify it
 **  under the terms of the GNU General Public License as published by the Free
 **  Software Foundation, either version 3 of the License, or (at your option)
 **  any later version.
 **
 **  This program is distributed in the hope that it will be useful, but WITHOUT
 **  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 **  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
 **  more details.
 **
 **  You should have received a copy of the GNU General Public License along
 **  with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef __CONFIG__
#define __CONFIG__

/* Name of package. */
#define PACKAGE				"iwrecord"

/* Version number of package. */
#define VERSION				"1.0-devel"

/* Description of package. */
#define DESCRIPTION			"A tool to record wireless traffic."

/* Define to the version of this package. */
#define PACKAGE_VERSION		VERSION

/* Define to the full name of this package. */
#define PACKAGE_NAME		PACKAGE

/* Define to the full name and version of this package. */
#define PACKAGE_STRING		PACKAGE " " VERSION

/* Define to the description of this package. */
#define PACKAGE_DESCRIPTION	DESCRIPTION

/* Define to the home page for this package. */
#define PACKAGE_URL			"http://github.com/jmlemetayer/iwrecord"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT	"http://github.com/jmlemetayer/iwrecord/issues"

#endif /* __CONFIG__ */
