# for this to work, you obviously have to have the
# .iso mounted as a loopback image
cp blowfish_sms.py /Volumes/SDCARD/sl4a/scripts
# you have to restart the emulator
#./adb -s emulator-5554 reboot
