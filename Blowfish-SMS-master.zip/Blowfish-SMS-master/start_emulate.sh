./tools/emulator -avd blowfish_sms -sdcard blowfish_sms_sdcard.iso
